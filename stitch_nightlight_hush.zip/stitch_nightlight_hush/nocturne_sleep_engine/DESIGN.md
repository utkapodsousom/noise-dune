---
name: Nocturne Sleep Engine
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1b1b1b'
  surface-container: '#1f1f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#d7c3b1'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#303030'
  outline: '#a08e7d'
  outline-variant: '#524437'
  surface-tint: '#ffb86a'
  primary: '#ffb86a'
  on-primary: '#492900'
  primary-container: '#d98e32'
  on-primary-container: '#502e00'
  inverse-primary: '#895200'
  secondary: '#f8ba7d'
  on-secondary: '#4a2800'
  secondary-container: '#673d0a'
  on-secondary-container: '#e5a96e'
  tertiary: '#79d1ff'
  on-tertiary: '#003549'
  tertiary-container: '#3ea9da'
  on-tertiary-container: '#003a51'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdcbc'
  primary-fixed-dim: '#ffb86a'
  on-primary-fixed: '#2c1700'
  on-primary-fixed-variant: '#683d00'
  secondary-fixed: '#ffdcbe'
  secondary-fixed-dim: '#f8ba7d'
  on-secondary-fixed: '#2c1600'
  on-secondary-fixed-variant: '#673d0a'
  tertiary-fixed: '#c3e8ff'
  tertiary-fixed-dim: '#79d1ff'
  on-tertiary-fixed: '#001e2c'
  on-tertiary-fixed-variant: '#004c68'
  background: '#131313'
  on-background: '#e2e2e2'
  surface-variant: '#353535'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '300'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 38px
    fontWeight: '300'
    lineHeight: 46px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '400'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '400'
    lineHeight: 30px
    letterSpacing: 0em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2.5rem
  margin-mobile: 1.5rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1.25rem
  space-lg: 2rem
  space-xl: 3.5rem
---

## Brand & Style

This design system is engineered for zero-disruption operation in light-deprived environments. It serves exhausted parents navigating pitch-black nurseries where standard screen emissions disrupt infant sleep cycles and shock dark-adapted vision. 

The aesthetic is ultra-minimalist, monastic, and somatic. Interaction relies on tactile spatial familiarity and generous negative space rather than visual scanning. The emotional state target is absolute de-escalation: low cognitive load, zero visual glare, and somatic calm. 

Visual principles:
- **Absolute True Pitch Black**: Leverages emissive OLED physics; unused pixels emit zero photons.
- **Warm Candlelight Dominance**: Emits exclusively in long wavelengths (amber/crimson) to minimize circadian suppression and avoid pupil constriction.
- **Whisper Visual Hierarchy**: Elements emerge subtly from the void and recede immediately after interaction. No hard dividers or perimeter boundaries.

## Colors

The palette operates on a strict optical preservation hierarchy:

- **Canvas & True Background**: `#000000` (Pitch Black). Must remain pure black without elevation tinting across base views to maintain physical pixel shut-off.
- **Primary Candlelight Accent**: `#D98E32` (Muted Warm Amber). Used for active states, running playback indicators, and primary touch targets. Emits a calm, non-activating warmth reminiscent of incandescent filament or candlelight.
- **Secondary Tone**: `#7A4D1A` (Deep Smoldering Amber). Used for secondary active elements, subtle progress fills, and ambient depth.
- **Text & Foreground System**:
  - `High Contrast (Essential Only)`: `#A1A1AA` (Dimmed Zinc). Used strictly for active time markers and primary track names.
  - `Standard Foreground`: `#71717A` (Muted Zinc). Used for standard copy, body states, and interactive icons.
  - `Low-Attunement Muted`: `#52525B` (Dim Slate). Used for contextual labels, inactive track names, and baseline metadata.
  - `Subtle Presence / Outlines`: `#27272A` (Charcoal). Used strictly where faint orientation guides are needed; rendered at low opacity to prevent edge glare.
- **Interactive States**:
  - Pressed/Active: `#B87322`
  - Subtle Hover/Touch highlight: `rgba(217, 142, 50, 0.08)`

## Typography

Typography prioritizes quiet legibility at low luminance without harsh light diffusion.

- **Display & Headings**: `Space Grotesk` introduces clean, modern geometry. Set in light and regular weights with tight, relaxed tracking, it reads effortlessly without stark density.
- **Body & Controls**: `Plus Jakarta Sans` provides soft, non-geometric terminals and generous inner counters that maintain legibility at low brightness levels and when viewed off-axis or with bleary eyes.
- **Weight Restraint**: Weights are constrained between 300 (Light) and 500 (Medium). Bold weights (700+) are forbidden, as heavy stroke masses emit unnecessary light blooming on dark-adapted retinas.
- **Contrast Disciplines**: Pure white (`#FFFFFF`) is prohibited. All type is dimmed zinc or slate to safeguard eye accommodation.

## Layout & Spacing

The layout philosophy uses an uncluttered, single-focus spatial rhythm. It eliminates multi-column grids in mobile views to create an undisturbed central axis for single-thumb navigation while holding an infant.

- **Canvas Boundaries**: Mobile views maintain a generous `1.5rem` outer margin to prevent accidental edge triggers while holding a phone with one hand.
- **Target Sizes**: Interactive elements must respect a minimum touch envelope of `56x56px` regardless of visual size to accommodate fatigued motor control in the dark.
- **Vertical Spacing Rhythm**: Screens lean heavily on `space-lg` and `space-xl` intervals to isolate functional blocks. Visual separation is accomplished entirely through empty spatial intervals rather than horizontal rule lines or border enclosures.

## Elevation & Depth

Standard elevation practices (e.g., white-cast drop shadows, ambient gray containers) fail on true OLED black screens. This system establishes depth through **Pure Surface Absorption and Filament Luminescence**:

- **Depth Planes**:
  - `Level 0 (Canvas Void)`: `#000000` (Emissive off). Base screen layer.
  - `Level 1 (Subtle Vessel)`: `#09090B` with `border: 1px solid rgba(39, 39, 42, 0.4)`. Used sparingly for interactive modules.
  - `Level 2 (Active Plinth)`: `#121215` with `border: 1px solid rgba(217, 142, 50, 0.15)`. Used for selected soundscapes or active timers.
- **Shadows & Glow**:
  - Drop shadows are absent.
  - In place of shadows, active playing states emit an extremely diffused low-intensity warm filament glow: `box-shadow: 0 0 32px -8px rgba(217, 142, 50, 0.12)`. This softens the edge of active nodes without creating room illumination.

## Shapes

The interface embraces a gentle, organic pill-shaped geometry (`roundedness: 3`) to eliminate sharp visual edges. 

- Interactive controls, status tags, floating dials, and selection indicators leverage fully rounded pill profiles (`9999px`).
- Larger containment blocks (sleep modules, timer selector sheets) utilize soft, expansive radius treatments (`rounded-xl` / `3rem`) to sustain a soothing, protective physical posture.

## Components

### Buttons & Interactive Triggers
- **Master Play/Pause Dial**: A large central circular trigger (`88x88px`). Inactive: bordered by `rgba(113, 113, 122, 0.3)`. Active: bordered by `#D98E32` with an internal soft radial glow (`rgba(217, 142, 50, 0.08)`).
- **Secondary Actions**: Fully pill-shaped (`roundedness: 3`), minimum height `48px`, background `rgba(39, 39, 42, 0.3)`, text `#71717A`. On press, backgrounds shift to `rgba(217, 142, 50, 0.12)` with `#D98E32` text.

### Chips (Sound Profiles & Timers)
- Sound selector chips (e.g., "Brownian Stream", "Womb Pulse", "Heavy Rain") use a pill silhouette with `padding: 10px 20px`.
- Unselected: Background transparent, border `1px solid rgba(39, 39, 42, 0.5)`, text `#52525B`.
- Selected: Background `rgba(217, 142, 50, 0.08)`, border `1px solid #D98E32`, text `#D98E32`, subtle diffuse glow.

### Volume & Intensity Sliders
- Linear, thick-line touch tracks (`8px` track height, rounded caps).
- Inactive track: `#18181B`.
- Active fill: `#D98E32`.
- Thumb control: Oversized `28px` floating pill handle with zero glow when stationary; transitions to a subtle filament glow under drag interaction.

### Lists & Selection Rows
- Edge-to-edge full width with generous vertical padding (`space-md`).
- Dividers are strictly omitted. Separation occurs via typographic rhythm and alternating alignment.
- Leading status indicator: A single `6px` organic breathing dot in `#D98E32` designating the active nocturnal profile.

### Cards & Grouping
- Enclosure cards are avoided where typography alone suffices. When required for grouping presets, use a deeply recessed `#08080A` surface with zero shadow and a hairline border of `rgba(39, 39, 42, 0.35)`.